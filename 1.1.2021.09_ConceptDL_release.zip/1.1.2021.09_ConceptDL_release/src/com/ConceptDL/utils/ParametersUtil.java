package com.ConceptDL.utils;

/**
 * @ClassName: PropertiesUtil
 * @Description: Set the related parameters.
 * @author Dr. Mi
 * @date Sep. 12, 2021
 * @since jdk1.8
 */
public class ParametersUtil {
	/** A demo example, a training and testing from Training 10% of SZCXR. */
	public static String train_path = "./data/train[1].csv";
	public static String test_path = "./data/test[1].csv";


	public static String methodType = "conceptCS";
	/** Show the results by bachSize or overall accuracies.*/
	public static String showResult="overall";// bachSize or overall 
	
	/** Fixed Lambda(i): concept falling space, the $\lambda $ value and P */
	public static int lambda  = 8; // it represents lambda = 8/10
	public static double P = 1;// concept falling, P=1 or P=0.1
	/** Epsion cocnept */
	public static double e=0.9;// it means the similarity of two samples, CosineDistance [0,1].
	/** MaxSize: The size of concept spaces for each class. */
	public static int conceptSZ =100;
	/** Chunk size: The size of each data chunk. */
	public static int C =10;

	/** Fixed Alpha: The concept similarity threshold. */
	public static double distF = 0.5;
	/** Fixed Delta: The range of the local $\alpha$-concept neighborhood. default radius=5. */
	public static int radius = 5;
}
