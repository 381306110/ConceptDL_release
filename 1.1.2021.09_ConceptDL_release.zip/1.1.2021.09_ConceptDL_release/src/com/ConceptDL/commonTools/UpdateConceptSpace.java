package com.ConceptDL.commonTools;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ExecutionException;

import com.ConceptDL.utils.MathMethodUtil;
import com.ConceptDL.utils.ParametersUtil;

/**
 * @ClassName: UpdateConceptSpace
 * @Description: 更新需保存原来的概念，人的记忆在形成新的概念时同时保留了旧的概念。
 * @author Dr. Yunlong Mi
 * @date Oct. 20, 2019
 * @since jdk1.8
 */

public class UpdateConceptSpace {
	/**
	 * @details Add the new forming concepts into the original concept pools.
	 * @param conceptPoolList
	 * @param errorIntentList
	 * @param errorConceptList
	 * @param conceptList
	 * @throws InterruptedException
	 * @throws ExecutionException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void updateConceptList(ArrayList<Map<double[], Set<Integer>>> conceptPoolList,
			List<double[]> errorIntentList, List<Map<double[], Set<Integer>>> conceptList)
			throws InterruptedException, ExecutionException {
		/** Remove error concepts from existing concept pools. */
		for (int i = 0; i < conceptPoolList.size(); ++i) {
			for (int j = 0; j < errorIntentList.size(); ++j) {
				Map<double[], Set<Integer>> conceptMap = (HashMap<double[], Set<Integer>>) conceptPoolList.get(i);
				if (conceptMap.containsKey(errorIntentList.get(j))) {
					conceptPoolList.get(i).remove(errorIntentList.get(j));
				} // end_of_if
			} // end_of_for
		} // end_of_for
		/** Add concepts into concept pools. */
		for (int i = 0; i < conceptList.size(); ++i) {
			if (conceptList.get(i).size() != 0) {
				conceptPoolList.get(i).putAll(conceptList.get(i));
			} // end_of_if
		} // end_of_for
		errorIntentList.clear();
		conceptList.clear();

		/** Concept fusion process. */
		HashMap<double[], Set<Integer>> tempConceptMap = new HashMap<double[], Set<Integer>>();
		int count = 0;// record the number of radius
		for (int i = 0; i < conceptPoolList.size(); ++i) {// for each class
			/** Consider the size of each concept space being greater than the given size. */
			if (conceptPoolList.get(i).size() >= ParametersUtil.conceptSZ) {// set the initial size of each class
				// System.out.println("conceptPoolList.get(i).size()==" +
				// conceptPoolList.get(i).size());
				List<double[]> keyList = new ArrayList(conceptPoolList.get(i).keySet());// get intent list
				List<Set<Integer>> valueList = new ArrayList(conceptPoolList.get(i).values());// get extent list
				for (int j = 0; j < keyList.size();) {
					double[] intent = keyList.get(j);// get intent
					Set<Integer> extent = valueList.get(j);// get extent
					Set<Integer> centerExtent = new TreeSet();// get extent with a virtual set
					/**
					 * For the virtual concepts (extent.size >1), it will be added into concept
					 * spaces directly; Otherwise, in the range of radius , if the similarity degree
					 * between two instances is greater than the given value, a new concept will be
					 * produced. Then, for the rest of concepts, the same operation will be
					 * conducted with the given radius. <br/>
					 */
					int k = j + 1;
					if (extent.size() > 1) {
						tempConceptMap.put(intent, extent);
					} else {
						/**
						 * 此处,k=j 用于实现对除去上一 radius 内所有概念之后,下一 radius 中概念进行学习. <br/>
						 * 后面的 j=j+count, 保证上一个 for 中的 j 也进行滑动 k 个大小.
						 */
						for (; k < keyList.size(); ++k) {
							double[] nextIntent = keyList.get(k);// get the intent of the next concept
							Set<Integer> nextExtent = valueList.get(k);// get the extent of the next concept
							double dist = MathMethodUtil.getCosineDistance(intent, nextIntent);
							/**
							 * Case 1: for k==(keyList.size()-1) and count< radius, the final instances in a
							 * list; <br/>
							 * Case 2: for count < radius and dist > the given value, constructing new
							 * concepts;<br/>
							 * Case 3: for count= radius, it will put the constructed concept into concept
							 * spaces.
							 */
							if (count < ParametersUtil.radius) {
								/** 融合在一定距离内的; 对于大于此距离的直接加入以便在下次融合 */
								if (dist > ParametersUtil.distF) {// V1.1
									double[] aveIntent = MathMethodUtil.getAverageDistance(intent, nextIntent);
									intent = aveIntent;
									count++;
								} else {
									tempConceptMap.put(nextIntent, nextExtent);
								} // end_of_if
							} else {// to skip the inner for loop
								tempConceptMap.put(intent, centerExtent);// 求外延并时代,用虚拟空表示
								break;
							} // end_of_if
						} // end_of_for
						if (count < ParametersUtil.radius) {
							if (count == 0) {// 最后一块若没有可以融合的,则需直接加入
								tempConceptMap.put(intent, extent);
							} else {
								tempConceptMap.put(intent, centerExtent);
							}
						} // end_of_if
					} // end_of_if
					j = k;
					count = 0;
				} // end_of_for
				conceptPoolList.get(i).clear();
				conceptPoolList.get(i).putAll(tempConceptMap);
				tempConceptMap.clear();// clear the temporary concept space for next computing
			} // end_of_if
		} // end_of_for
	}// end_of_updateConceptList
}