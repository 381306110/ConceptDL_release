package com.ConceptDL.initialS;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;
import java.util.Map.Entry;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.Future;
import java.util.concurrent.RecursiveTask;
import com.ConceptDL.utils.MathMethodUtil;
import com.ConceptDL.utils.ParametersUtil;

/**
 * @ClassName: GetLatticeSpace
 * @Description: to get concept space, saves a concept by <intent, extent>
 *               rather than <extent,intent>.
 * @author Dr. Yunlong.MI
 * @date 2020年6月7日
 * @since jdk1.8
 */
public class GetConceptSpace {
	HashMap<double[], Set<Integer>> map = new HashMap<double[], Set<Integer>>();

	@SuppressWarnings("unchecked")
	public List<Map<double[], Set<Integer>>> getConceptSpace(double[][] tempX, HashMap<Integer, Integer> tempY,
			double al) throws Exception {
		/** (1) 获取所需要的起始行与终止行、起始列与终止列 */
		List<Map<double[], Set<Integer>>> conceptSpaceList = new ArrayList<Map<double[], Set<Integer>>>();

		/** (2) 并发：根据classNumber将样本集划分成不同类别[即决策类别] */
		int beginClassNum = 0, endClassNum = tempY.size() - 1;// begin to 0, and end with tempY.size() - 1.
		ForkJoinPool forkJoinPool = new ForkJoinPool();
		Future<Vector<Object>> future = null;
		future = forkJoinPool.submit(new ComputeConceptTask(tempX, tempY, beginClassNum, endClassNum, al));
		Vector<Object> vec = future.get();
		forkJoinPool.shutdown();
		conceptSpaceList.addAll((Collection<? extends Map<double[], Set<Integer>>>) vec);
		return conceptSpaceList;
	}// end_of_getLLatticeSet

	/**
	 * @param X
	 * @param type
	 * @param beginRowNum
	 * @param endRowNum
	 * @param al
	 * @return HashMap<double[], Set<Integer>> 根据类别信息获取某一类的概念空间
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public HashMap<double[], Set<Integer>> constructConceptSpace(double[][] X, int type, int beginRowNum, int endRowNum,
			double al) throws Exception {
		HashMap<double[], Set<Integer>> tempLMap = new HashMap<double[], Set<Integer>>();
		TreeSet<Integer> objectSet = new TreeSet<Integer>();// 由于都是以同一个objectSet来存，只有一个引用。key相同，则值会改。
		// int maxValue=0, index=0; // initialize maxValue to 0
		// double[] intent;// gets its corresponding intent
		/** 对象为线索：对象--属性 ：概念 */
		for (int row = beginRowNum; row <= endRowNum; ++row) {
			// (1) 获取一行的属性、先从对象出发
			double[] attributeList = X[row];
			// (2) 由属性集求取对象集并构成条件概念格;若多次出现同一个instance，可认为是认知加强
			if (!tempLMap.containsKey(attributeList)) {// If it does not exist in the concept pool.
				objectSet = getObjectSet(X, type, attributeList, beginRowNum, endRowNum);
				tempLMap = getConceptSet((TreeSet<Integer>) objectSet.clone(), attributeList, al);
			} // end_of_if
			/** (3) gets the max size of extent and its corresponding intent */
			objectSet.clear();
		} // end_of_for
		return tempLMap;
	}// end_of_constructLatticeNode

	/**
	 * @param x
	 * @param type
	 * @param attributeList
	 * @param beginRowNum
	 * @param endRowNum
	 * @return TreeSet<Integer>
	 * @throws Exception
	 */
	private TreeSet<Integer> getObjectSet(double[][] x, int type, double[] attributeList, int beginRowNum,
			int endRowNum) throws Exception {
		TreeSet<Integer> objectSet = new TreeSet<Integer>();//
		for (int row = beginRowNum; row <= endRowNum; ++row) {
			boolean flag = true;
			// for (int i = 0; i < attributeList.length; ++i) {
			// if (!(x[row][i] >= attributeList[i])) {
			// flag = false;
			// break;
			// }
			// } // end_of_for_attributeList
			double eValue = MathMethodUtil.getCosineDistance(x[row], attributeList);
			if (eValue <= ParametersUtil.e) {
				flag = false;
			} // end_of_if
			if (flag) {
				objectSet.add(row);
			} // end_of_if
			flag = true;
		} // end_of_for_endRowNum
		return objectSet;
	}// end_of_getObjectSet

	/**
	 * @param objectSet
	 * @param attributeList
	 * @param al
	 * @return concept: <key,value>-<intent,extent>, and it is different from
	 *         classical concepts.
	 */
	private HashMap<double[], Set<Integer>> getConceptSet(TreeSet<Integer> objectSet, double[] attributeList,
			double al) {
		@SuppressWarnings("unchecked")
		HashMap<double[], Set<Integer>> tempMap = (HashMap<double[], Set<Integer>>) map.clone();
		boolean isUnion = true;
		/** 在此进概念聚类，按概念生成的顺序进行 */
		if (tempMap.size() != 0) {// It is not the first time, and it means tempMap is greater than 0.
			for (Entry<double[], Set<Integer>> entry : tempMap.entrySet()) {
				double[] key = entry.getKey(); // gets intent
				Set<Integer> value = entry.getValue(); // gets extent
				/**
				 * 序关系判定:(1) objectSet大于value，即A大于B结构;(2)objectSet小于value，即A小于B结构.
				 * 注意：是存在这着序关系后才确定是否在于theta值，不是任意两个对象都可以比较。
				 */
				if (objectSet.containsAll(value)) {
					int union = objectSet.size();
					int intersection = value.size();
					double theta = (double) intersection / union;
					/** 进行合并：对象取并，属性取均值: 1.只有存在序关系才合(若A大于B,则有AIB=B)；2.只有大于theta值合并 */
					if (theta >= al) {
						isUnion = false;
						double[] attribueAve = getAve(key, attributeList);
						map.remove(key);// 去掉被合并前的原有概念
						map.put(attribueAve, objectSet);// intent-extent
						attributeList = attribueAve;
					}
				} else if (value.containsAll(objectSet)) {
					int union = value.size();
					int intersection = objectSet.size();
					double theta = (double) intersection / union;
					if (theta >= al) {
						isUnion = false;
						double[] attribueAve = getAve(key, attributeList);
						map.put(attribueAve, value);// attributeList = attribueAve不成立;
						break;// 若某个概念包括生成概念则认为不需要再融合进去
					}
				} // end_of_if
			} // end_of_for
			if (isUnion) {// It is an atomic concept.
				map.put(attributeList, objectSet);
			}
		} else {// The first time, tempMap=0 due to map=0.
			map.put(attributeList, objectSet);
		} // end_of_if
		return map;
	}// end_of_getConceptSet

	/**
	 * @param value2
	 * @param attributeList2
	 * @return get the average value of two vectors
	 */
	private double[] getAve(double[] value2, double[] attributeList2) {
		double[] attributeList = new double[attributeList2.length];
		for (int index = 0; index < value2.length; ++index) {
			double value = (value2[index] + attributeList2[index]) / 2;
			attributeList[index] = value;
		} // end_of_for
		return attributeList;
	}// end_of_getAve
}// end_of_GetConceptSpace

/**
 * @className ComputeConceptTask
 * @author YunlongMi
 * @details 继承RecursiveAction来实现“可分解”的任务
 */
class ComputeConceptTask extends RecursiveTask<Vector<Object>> {
	private static final long serialVersionUID = -9140435922317983096L;
	private double[][] tempX;
	private int beginClassNum, endClassNum;
	private double al;
	private HashMap<Integer, Integer> tempY;
	private static final int MAX = 1;

	public ComputeConceptTask(double[][] tempX, HashMap<Integer, Integer> tempY, int beginClassNum, int endClassNum,
			double al) {
		this.tempX = tempX;
		this.tempY = tempY;
		this.beginClassNum = beginClassNum;
		this.endClassNum = endClassNum;
		this.al = al;
	}

	@Override
	protected Vector<Object> compute() {
		if ((endClassNum - beginClassNum) < MAX) {// 每类一个线程运行
			HashMap<double[], Set<Integer>> lMap = new HashMap<double[], Set<Integer>>();
			int beginRowNum = 0;
			for (int i = 0; i < beginClassNum; ++i) { // 获取第类的开始行
				beginRowNum += tempY.get(i);
			}
			int endRowNum = tempY.get(endClassNum) + beginRowNum - 1;// 获取第类的结束行
			try {
				lMap = new GetConceptSpace().constructConceptSpace(tempX, endClassNum, beginRowNum, endRowNum, al);
			} catch (Exception e) {
				e.printStackTrace();
			}
			Vector<Object> tempVec = new Vector<Object>();
			// tempVec.add(endClassNum);
			tempVec.add(lMap);
			return tempVec;
		} else {
			int middle = (endClassNum + beginClassNum) / 2;
			ComputeConceptTask left = new ComputeConceptTask(tempX, tempY, beginClassNum, middle, al);
			ComputeConceptTask right = new ComputeConceptTask(tempX, tempY, middle + 1, endClassNum, al);
			left.fork();
			right.fork();
			left.join().addAll(right.join());// 从小到大收集[按线程编号]
			return left.join();
		} // end_of_if_Max
	}// end_of_compute
}// end_of_ComputeConceptTask